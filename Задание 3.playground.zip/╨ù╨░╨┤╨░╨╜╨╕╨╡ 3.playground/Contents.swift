
import Foundation

class Product: CalorieCountProtocol {
    var calories: Int
    var productType: ProductType
    var name: String
    
    init (name: String, productType: ProductType, calories: Int){
        
        self.name = name
        self.productType = productType
        self.calories = calories
    }
    
    func description() -> String {
        let desk = "Каллорий в \(name) - \(calories)"
        return desk
    }
    
    
}

struct Product2: CalorieCountProtocol {
    
    var name: String
    var productType: ProductType
    var calories: Int
    
    func description() -> String {
        let desk = "Каллорий в \(name) - \(calories)"
        return desk
    }
    
    
}


protocol CalorieCountProtocol {
     var calories: Int { get }
     func description() -> String
}

enum ProductType {

    case fruit, vegetable, meat
}
let avakado = Product(name: "Авакадо", productType: .vegetable, calories: 254)
let bannana = Product2(name: "Банан", productType: .fruit, calories: 145)

avakado.calories
bannana.calories


// Задание 2

enum BalanceType: Equatable {
    case positive, negative, neutral
}

struct Balance: Equatable {
    let type: BalanceType
    let amount: Int
}

class BalanceObject: Equatable {
    
    let type: BalanceType = .neutral
    var amount: Int = 0
    
    static func == (lhs: BalanceObject, rhs: BalanceObject) -> Bool {
        return lhs.amount == rhs.amount &&
        lhs.type == rhs.type
    }
    }





let home = BalanceObject()
let balance = Balance(type: .neutral, amount: 5)

balance == home
