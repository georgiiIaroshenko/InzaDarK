
import Foundation


class Salary {
        func notifyWhenCashEnds(completion: @escaping () -> Void) {
        …
            completion()
        }
}
