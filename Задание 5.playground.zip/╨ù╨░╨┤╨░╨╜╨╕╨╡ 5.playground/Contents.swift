
import Foundation

var fruits = [String] ()
var fruitsPlus = ["orange", "apple", "banana", "grapefruit"]
var redFood = ["apple", "tomato", "grapefruit", "strawberry"]

fruits = fruitsPlus + redFood

print(fruits)

